module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    var headers = new Object();
    headers['Compute-Type'] = 'function';
    var json = JSON.stringify({
        body: req.body,
        headers: headers,
        statusCode: 200,
    });
    context.res = {
        // status: 200, /* Defaults to 200 */
        body: json
    };
    context.done();
};
